#include <stdio.h>
#include <GL/glew.h>

void createShade();
void drawShade();

extern unsigned int shade_vao;
