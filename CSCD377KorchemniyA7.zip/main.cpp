#include <GL/glew.h>
#include <GL/freeglut.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <IL/il.h>
#include <IL/ilu.h>
#include <IL/ilut.h>

#include "Plane.h"
#include "Cube.h"
#include "roof.h"

#define GLM_FORCE_RADIANS 

#include <glm/mat4x4.hpp> // glm::mat4
#include <glm/gtc/matrix_transform.hpp> // glm::translate, glm::rotate, glm::scale, glm::perspective

using namespace glm;

GLuint matrix_loc;
GLuint projection_matrix_loc;
GLuint view_matrix_loc;
GLuint program;
GLuint TextureStone, TextureOrangeWood, TextureLightWood, TextureGrass;

//different boolean variables
bool show_line = false;
bool top_view = false;

const double kPI = 3.1415926535897932384626433832795;

mat4 view_matrix(1.0f);
mat4 projection_matrix(1.0f);

mat4 model_matrix(1.0f);

//Add light components
vec4 light_position(5.0, 10.0, 5.0, 1.0);
vec3 light_ambient(0.3, 0.3, 0.3);
vec3 light_color(1.0, 1.0, 1.0);
vec3 material_color(0.9, 0.5, 0.3);
float shininess = 50.0f;

// uniform indices of light
GLuint ambient_loc;
GLuint light_source_loc;
GLuint light_position_loc;
GLuint material_color_loc;
GLuint shininess_loc;

GLfloat eye[3] = { 0.0f, 2.75f, 8.0f };
GLfloat center[3] = { 0.0f, 0.0f, 0.0f };
GLfloat offset = 0.0;

GLfloat rotateAngle = 0.0f;

char* ReadFile(const char* filename);
GLuint initShaders(const char* v_shader, const char* f_shader);
void keyboard(unsigned char key, int x, int y);

char* ReadFile(const char* filename) {

	FILE* infile;
#ifdef WIN32
	fopen_s(&infile, filename, "rb");
#else
	infile = fopen(filename, "rb");
#endif

	if (!infile) {
		printf("Unable to open file %s\n", filename);
		return NULL;
	}

	fseek(infile, 0, SEEK_END);
	int len = ftell(infile);
	fseek(infile, 0, SEEK_SET);
	char* source = (char*)malloc(len + 1);
	fread(source, 1, len, infile);
	fclose(infile);
	source[len] = 0;
	return (source);
}

/*************************************************************/
/*************************************************************/

GLuint initShaders(const char* v_shader, const char* f_shader) {

	GLuint p = glCreateProgram();

	GLuint v = glCreateShader(GL_VERTEX_SHADER);
	GLuint f = glCreateShader(GL_FRAGMENT_SHADER);

	const char * vs = ReadFile(v_shader);
	const char * fs = ReadFile(f_shader);

	glShaderSource(v, 1, &vs, NULL);
	glShaderSource(f, 1, &fs, NULL);

	free((char*)vs);
	free((char*)fs);

	glCompileShader(v);
	GLint compiled;

	glGetShaderiv(v, GL_COMPILE_STATUS, &compiled);
	if (!compiled) {
		GLsizei len;
		glGetShaderiv(v, GL_INFO_LOG_LENGTH, &len);
		char* log = (char*)malloc(len + 1);
		glGetShaderInfoLog(v, len, &len, log);
		printf("Vertex Shader compilation failed: %s\n", log);
		free(log);
	}

	glCompileShader(f);
	glGetShaderiv(f, GL_COMPILE_STATUS, &compiled);

	if (!compiled) {
		GLsizei len;
		glGetShaderiv(f, GL_INFO_LOG_LENGTH, &len);
		char* log = (char*)malloc(len + 1);
		glGetShaderInfoLog(f, len, &len, log);
		printf("Vertex Shader compilation failed: %s\n", log);
		free(log);
	}

	glAttachShader(p, v);
	glAttachShader(p, f);
	glLinkProgram(p);
	GLint linked;

	glGetProgramiv(p, GL_LINK_STATUS, &linked);

	if (!linked) {
		GLsizei len;
		glGetProgramiv(p, GL_INFO_LOG_LENGTH, &len);
		char* log = (char*)malloc(len + 1);
		glGetProgramInfoLog(p, len, &len, log);
		printf("Shader linking failed: %s\n", log);
		free(log);
	}

	glUseProgram(p);
	return p;
}

/********************************************************/
unsigned int loadTexture(const char* filename) {
	ILboolean success;
	unsigned int imageID;

	ilGenImages(1, &imageID);

	ilBindImage(imageID);
	ilEnable(IL_ORIGIN_SET);
	ilOriginFunc(IL_ORIGIN_LOWER_LEFT);
	success = ilLoadImage((ILstring)filename);

	if (!success) {
		printf("Couldn't load the following texture file: %s", filename);
		ilDeleteImages(1, &imageID);
		return 0;
	}

	ilConvertImage(IL_RGBA, IL_UNSIGNED_BYTE);

	GLuint tid;
	glGenTextures(1, &tid);
	glBindTexture(GL_TEXTURE_2D, tid);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, ilGetInteger(IL_IMAGE_WIDTH), ilGetInteger(IL_IMAGE_HEIGHT), 0,
		GL_RGBA, GL_UNSIGNED_BYTE, ilGetData());

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	glBindTexture(GL_TEXTURE_2D, 0);

	ilDeleteImages(1, &imageID);
	return tid;
}

/*******************************************************/
void Initialize(void) {
	program = initShaders("shader_picnic_table.vs", "shader_picnic_table.fs");

	model_matrix = mat4(1.0f);
	view_matrix_loc = glGetUniformLocation(program, "view_matrix");
	matrix_loc = glGetUniformLocation(program, "model_matrix");
	projection_matrix_loc = glGetUniformLocation(program, "projection_matrix");

	createPlane();
	createCube();
	createShade();

	glUniformMatrix4fv(matrix_loc, 1, GL_FALSE, (GLfloat*)&model_matrix[0]);
	projection_matrix = perspective(radians(90.0f), 1.0f, 1.0f, 20.0f);
	glUniformMatrix4fv(projection_matrix_loc, 1, GL_FALSE, (GLfloat*)&projection_matrix[0]);

	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

	ambient_loc = glGetUniformLocation(program, "Ambient");
	glUniform3fv(ambient_loc, 1, (GLfloat*)&light_ambient[0]);

	material_color_loc = glGetUniformLocation(program, "MaterialColor");
	glUniform3fv(material_color_loc, 1, (GLfloat*)&material_color[0]);

	light_source_loc = glGetUniformLocation(program, "LightColor");
	glUniform3fv(light_source_loc, 1, (GLfloat*)&light_color[0]);

	light_position_loc = glGetUniformLocation(program, "LightPosition");
	glUniform4fv(light_position_loc, 1, (GLfloat*)&light_position[0]);

	shininess_loc = glGetUniformLocation(program, "Shininess");
	glUniform1f(shininess_loc, shininess);

	glUniform1i(glGetUniformLocation(program, "Tex1"), 0);
	TextureStone = loadTexture("stone.jpg");
	TextureGrass = loadTexture("grass.jpg");
	TextureLightWood = loadTexture("light-wood.jpg");
	TextureOrangeWood = loadTexture("orange-wood.jpg");

	glActiveTexture(GL_TEXTURE0);
}

void Display(void) {
	// Clear
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);

	// Setup view matrix
	view_matrix = glm::lookAt(vec3(eye[0], eye[1], eye[2]), glm::vec3(center[0], center[1], center[2]), glm::vec3(0.0f, 1.0f, 0.0f));
	view_matrix = rotate(view_matrix, radians(rotateAngle), vec3(0.0f, 1.0f, 0.0f));
	glUniformMatrix4fv(view_matrix_loc, 1, GL_FALSE, (GLfloat*)&view_matrix[0]);

	vec4 lightPosEye = view_matrix * light_position;
	glUniform4fv(light_position_loc, 1, (GLfloat*)&lightPosEye[0]);

	// Draws the pole 
	glBindTexture(GL_TEXTURE_2D, TextureOrangeWood);
	material_color = vec3(0.9, 0.5, 0.3);
	glUniform3fv(material_color_loc, 1, (GLfloat*)&material_color[0]);
	model_matrix = translate(mat4(1.0f), vec3(offset, 0.0, 0.0))*scale(mat4(1.0f), vec3(0.20, 8.0, 0.20));
	glUniformMatrix4fv(matrix_loc, 1, GL_FALSE, (GLfloat*)&model_matrix[0]);
	drawCube();

	// Draws the shade
	glBindTexture(GL_TEXTURE_2D, TextureOrangeWood);
	model_matrix = translate(mat4(1.0f), vec3(offset, 3.1, 0.0));
	glUniformMatrix4fv(matrix_loc, 1, GL_FALSE, (GLfloat*)&model_matrix[0]);
	drawShade();

	// Draws the tabletop
	glBindTexture(GL_TEXTURE_2D, TextureStone);
	model_matrix = translate(mat4(1.0f), vec3(offset, 0.0, 0.0)) * scale(mat4(1.0f), vec3(3.0, 0.25, 3.0));
	glUniformMatrix4fv(matrix_loc, 1, GL_FALSE, (GLfloat*)&model_matrix[0]);
	drawCube();

	// Draws the table legs
	glBindTexture(GL_TEXTURE_2D, TextureLightWood);
	mat4 shear_matrix = { 1, 0, 0, 0, 0.25, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1 };
	model_matrix = translate(mat4(1.0f), vec3(offset - 1, -2, 0.0));
	model_matrix = model_matrix * shear_matrix * scale(mat4(1.0f), vec3(0.4, 4.0, 0.4));
	glUniformMatrix4fv(matrix_loc, 1, GL_FALSE, (GLfloat*)&model_matrix[0]);
	drawCube();
	shear_matrix = { 1, 0, 0, 0, 0, 1, -0.25, 0, 0, 0, 1, 0, 0, 0, 0, 1 };
	model_matrix = translate(mat4(1.0f), vec3(offset, -2, 1));
	model_matrix = model_matrix * shear_matrix * scale(mat4(1.0f), vec3(0.4, 4.0, 0.4));
	glUniformMatrix4fv(matrix_loc, 1, GL_FALSE, (GLfloat*)&model_matrix[0]);
	drawCube();
	shear_matrix = { 1, 0, 0, 0, -0.25, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1 };
	model_matrix = translate(mat4(1.0f), vec3(offset + 1, -2, 0.0));
	model_matrix = model_matrix * shear_matrix * scale(mat4(1.0f), vec3(0.4, 4.0, 0.4));
	glUniformMatrix4fv(matrix_loc, 1, GL_FALSE, (GLfloat*)&model_matrix[0]);
	drawCube();
	shear_matrix = { 1, 0, 0, 0, 0, 1, 0.25, 0, 0, 0, 1, 0, 0, 0, 0, 1 };
	model_matrix = translate(mat4(1.0f), vec3(offset, -2, -1));
	model_matrix = model_matrix * shear_matrix * scale(mat4(1.0f), vec3(0.4, 4.0, 0.4));
	glUniformMatrix4fv(matrix_loc, 1, GL_FALSE, (GLfloat*)&model_matrix[0]);
	drawCube();

	// Draws the stools
	glBindTexture(GL_TEXTURE_2D, TextureLightWood);
	model_matrix = translate(mat4(1.0f), vec3(offset + 3.0, -3.0, 0.0)) * scale(mat4(1.0f), vec3(2.0, 2.0, 2.0));
	glUniformMatrix4fv(matrix_loc, 1, GL_FALSE, (GLfloat*)&model_matrix[0]);
	drawCube();
	model_matrix = translate(mat4(1.0f), vec3(offset - 3.0, -3.0, 0.0)) * scale(mat4(1.0f), vec3(2.0, 2.0, 2.0));
	glUniformMatrix4fv(matrix_loc, 1, GL_FALSE, (GLfloat*)&model_matrix[0]);
	drawCube();
	model_matrix = translate(mat4(1.0f), vec3(offset, -3.0, -3.0)) * scale(mat4(1.0f), vec3(2.0, 2.0, 2.0));
	glUniformMatrix4fv(matrix_loc, 1, GL_FALSE, (GLfloat*)&model_matrix[0]);
	drawCube();
	model_matrix = translate(mat4(1.0f), vec3(offset, -3.0, 3.0)) * scale(mat4(1.0f), vec3(2.0, 2.0, 2.0));
	glUniformMatrix4fv(matrix_loc, 1, GL_FALSE, (GLfloat*)&model_matrix[0]);
	drawCube();

	// Draws the ground
	glBindTexture(GL_TEXTURE_2D, TextureGrass);
	model_matrix = translate(mat4(1.0f), vec3(offset, -4.0, 0.0));
	glUniformMatrix4fv(matrix_loc, 1, GL_FALSE, (GLfloat*)&model_matrix[0]);
	material_color = vec3(0.0, 1.0, 0.0);
	glUniform3fv(material_color_loc, 1, (GLfloat*)&material_color[0]);
	drawPlane();

	glutSwapBuffers();
}


void keyboard(unsigned char key, int x, int y) {

	switch (key) {
		case 'q':case 'Q':
			exit(EXIT_SUCCESS);
			break;
		case 'u':case 'U':
			top_view = !top_view;
			if (top_view) {
				eye[1] = 10.0f;
				eye[2] = 0.000001;
			}
			else {
				eye[1] = 2.75f;
				eye[2] = 8.0f;
			}
			break;
	}
	glutPostRedisplay();
}

void rotate(int n) {
	switch (n) {
	case 1:
		rotateAngle += 1.0f;
		glutPostRedisplay();
		glutTimerFunc(20, rotate, 1);
		break;
	}
}

/*********/
int main(int argc, char** argv) {

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA|GLUT_DEPTH);
	glutInitWindowSize(800, 800);

	glutCreateWindow("Picnic Table");

	if (glewInit()) {
		printf("Unable to initialize GLEW ... exiting\n");
	}
	ilInit();
	Initialize();
	printf("%s\n", glGetString(GL_VERSION));
	glutDisplayFunc(Display);
	glutKeyboardFunc(keyboard);
	glutTimerFunc(20, rotate, 1);
	glutMainLoop();
	
	return 0;
}

/*************/



