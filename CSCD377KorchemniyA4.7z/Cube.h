#include <stdio.h>
#include <GL/glew.h>

void createCube();
void drawCube();

extern	unsigned int cube_vao;
