#include <stdio.h>
#include <GL/glew.h>

void createParasol();
void drawParasol();

extern unsigned int parasol_vao;
