#version 430 core

in vec4 fColor;
out vec4 finalColor;

void main(void) {
    finalColor = fColor;
}
